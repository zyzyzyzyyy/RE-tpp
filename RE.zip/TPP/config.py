import string
import random

common = {
    "exp_name": "CPR", 

    # "exp_name": "DUIE_ORG_SPO",  
    "test_exp_name":'cpr',   

    "rel2id": "rel2id.json",
    "ent2id": "ent2id.json",
    "device_num": 1,
    "encoder": "BERT", 
    "hyper_parameters": {
        "shaking_type": "cln_plus",#cln
        "inner_enc_type": "lstm",
        "dist_emb_size": 128,
        "add_dist": True,
        # match_pattern: only_head_text (nyt_star, webnlg_star), whole_text (nyt, webnlg), only_head_index, whole_span, event_extraction
        "match_pattern": "whole_text", 
    },
}
common["run_name"] = "{}+{}+{}".format("TP2", common["hyper_parameters"]["shaking_type"], common["encoder"]) + ""

train_config = {
    "train_data": "train.json",
    "valid_data": "test.json",
    "rel2id": "rel2id.json",
   
    "logger": "default", 
    "log_path": "./default_log_dir/{}.log".format(common["exp_name"]+'biobertdis'),
    "path_to_save_model": "./default_log_dir/{}".format(common["exp_name"]+'biobertdis'),

    # when to save the model state dict
    "f1_2_save": 0,
    # whether train_config from scratch
    "fr_scratch": True,
    # write down notes here if you want, it will be logged
    "note": "start from scratch",
    # if not fr scratch, set a model_state_dict
    "model_state_dict_path": "", # valid only if "fr_scratch" is False
    "hyper_parameters": {
        "batch_size": 16,
        "epochs": 100,
        "seed": 42,
        "log_interval": 10,
        "max_seq_len": 100,
        "sliding_len": 20,
        "scheduler": "CAWR", # Step
        "ghm": False, # set True if you want to use GHM to adjust the weights of gradients, this will speed up the training process and might improve the results. (Note that ghm in current version is unstable now, may hurt the results)
        "tok_pair_sample_rate": 1, # (0, 1] How many percent of token paris you want to sample for training, this would slow down the training if set to less than 1. It is only helpful when your GPU memory is not enought for the training.
    },
}

eval_config = {
    "model_state_dict_dir": "default_log_dir", # if use wandb, set "./wandb", or set "./default_log_dir" if you use default logger
    # "run_ids": ["1a70p109", ],
    "last_k_model": 1,
    "test_data": "test.json", # "*test*.json"
    'model_path':"default_log_dir/CPR/model_state_dict.pt",
    # results
    "save_res": False,#False
    "save_res_dir": "results",
    
    # score: set true only if test set is tagged
    "score": True,
    
    "hyper_parameters": {
        "batch_size": 16,
        "force_split": False,
        "max_seq_len": 512,
        "sliding_len": 50,
    },
}

bert_config = {
    # "data_home": "duuie/data4bert",
    "data_home": "CPR",
    "bert_path": "pretrained_models/biobert-v1.1", # bert-base-cased， chinese-bert-wwm-ext-hit
    # "bert_path":"bert-base-cased",
    "hyper_parameters": {
        "lr": 2e-5,
    },
}


cawr_scheduler = {
    # CosineAnnealingWarmRestarts
    "T_mult": 1,
    "rewarm_epoch_num": 2,
}
step_scheduler = {
    # StepLR
    "decay_rate": 0.999,
    "decay_steps": 100,
}

# ---------------------------dicts above is all you need to set---------------------------------------------------
if common["encoder"] == "BERT":
    hyper_params = {**common["hyper_parameters"], **bert_config["hyper_parameters"]}
    common = {**common, **bert_config}
    common["hyper_parameters"] = hyper_params

    
hyper_params = {**common["hyper_parameters"], **train_config["hyper_parameters"]}
train_config = {**train_config, **common}
train_config["hyper_parameters"] = hyper_params
if train_config["hyper_parameters"]["scheduler"] == "CAWR":
    train_config["hyper_parameters"] = {**train_config["hyper_parameters"], **cawr_scheduler}
elif train_config["hyper_parameters"]["scheduler"] == "Step":
    train_config["hyper_parameters"] = {**train_config["hyper_parameters"], **step_scheduler}
    
hyper_params = {**common["hyper_parameters"], **eval_config["hyper_parameters"]}
eval_config = {**eval_config, **common}
eval_config["hyper_parameters"] = hyper_params