import json
import jsonlines
import os
from tqdm import tqdm
import re
from IPython.core.debugger import set_trace
from pprint import pprint
import unicodedata
from transformers import BertModel, BasicTokenizer, BertTokenizerFast
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import torch.optim as optim
import glob
import time
from common.utils import Preprocessor
from tplinker_plus.tplinker_plus import (HandshakingTaggingScheme,
                          DataMaker4Bert, 
                          DataMaker4BiLSTM, 
                          TPLinkerPlusBert, 
                          TPLinkerPlusBiLSTM,
                          MetricsCalculator)

from tplinker_plus import config
import numpy as np

config = config.eval_config

os.environ["TOKENIZERS_PARALLELISM"] = "true"
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

data_home = config["data_home"]
experiment_name = config["test_exp_name"]
test_data_path = os.path.join(data_home, experiment_name, config["test_data"])
batch_size = config["hyper_parameters"]["batch_size"]
rel2id_path = os.path.join(data_home, experiment_name, config["rel2id"])
ent2id_path = os.path.join(data_home,experiment_name, config["ent2id"])
save_res_dir = os.path.join(config["save_res_dir"], experiment_name)
max_seq_len = config["hyper_parameters"]["max_seq_len"]
# for reproductivity
torch.backends.cudnn.deterministic = True

#load data
test_data_path_dict = {}
for file_path in glob.glob(test_data_path):
    file_name = re.search("(.*?)\.json", file_path.split("/")[-1]).group(1)
    test_data_path_dict[file_name] = file_path

test_data_dict = {}
for file_name, path in test_data_path_dict.items():
    test_data_dict[file_name] = json.load(open(path, "r", encoding = "utf-8"))
    # data = []
    # with open(path, "r", encoding = "utf-8") as f:
    #     lines = f.read().splitlines()
    #     for line in lines:
    #         data.append(json.loads(line))
    # test_data_dict[file_name] = data

#split
tokenizer = BertTokenizerFast.from_pretrained(config["bert_path"], add_special_tokens = False, do_lower_case = False)
tokenize = tokenizer.tokenize
get_tok2char_span_map = lambda text: tokenizer.encode_plus(text, return_offsets_mapping = True, add_special_tokens = False)["offset_mapping"]


preprocessor = Preprocessor(tokenize_func = tokenize, 
                            get_tok2char_span_map_func = get_tok2char_span_map)

all_data = []
for data in list(test_data_dict.values()):
    all_data.extend(data)
    
max_tok_num = 0
for sample in tqdm(all_data, desc = "Calculate the max token number"):
    tokens = tokenize(sample["text"])
    max_tok_num = max(len(tokens), max_tok_num)

split_test_data = False
if max_tok_num > max_seq_len:
    split_test_data = True
    print("max_tok_num: {}, lagger than max_test_seq_len: {}, test data will be split!".format(max_tok_num, max_seq_len))
else:
    print("max_tok_num: {}, less than or equal to max_test_seq_len: {}, no need to split!".format(max_tok_num, max_seq_len))
max_seq_len = min(max_tok_num, max_seq_len) 

if config["hyper_parameters"]["force_split"]:
    split_test_data = True
    print("force to split the test dataset!")    

ori_test_data_dict = copy.deepcopy(test_data_dict)
if split_test_data:
    test_data_dict = {}
    for file_name, data in ori_test_data_dict.items():
        test_data_dict[file_name] = preprocessor.split_into_short_samples(data, 
                                                                          max_seq_len, 
                                                                          sliding_len = config["hyper_parameters"]["sliding_len"], 
                                                                          encoder = config["encoder"], 
                                                                          data_type = "test")

#Decoder
rel2id = json.load(open(rel2id_path, "r", encoding = "utf-8"))
ent2id = json.load(open(ent2id_path, "r", encoding = "utf-8"))
handshaking_tagger = HandshakingTaggingScheme(rel2id, max_seq_len, ent2id)
tag_size = handshaking_tagger.get_tag_size()

#Dataset
if config["encoder"] == "BERT":
    tokenizer = BertTokenizerFast.from_pretrained(config["bert_path"], add_special_tokens = False, do_lower_case = False)
    data_maker = DataMaker4Bert(tokenizer, handshaking_tagger)
    get_tok2char_span_map = lambda text: tokenizer.encode_plus(text, return_offsets_mapping = True, add_special_tokens = False)["offset_mapping"]

class MyDataset(Dataset):
    def __init__(self, data):
        self.data = data
        
    def __getitem__(self, index):
        return self.data[index]
    
    def __len__(self):
        return len(self.data)

#Model
if config["encoder"] == "BERT":
    encoder = BertModel.from_pretrained(config["bert_path"])
    hidden_size = encoder.config.hidden_size
    rel_extractor = TPLinkerPlusBert(encoder, 
                                     tag_size,
                                     config["hyper_parameters"]["shaking_type"],
                                     config["hyper_parameters"]["inner_enc_type"],
                                    )
rel_extractor = rel_extractor.to(device)

#Merics
metrics = MetricsCalculator(handshaking_tagger)

#Prediction
# get model state paths
model_state_dir = config["model_state_dict_dir"]
# target_run_ids = set(config["run_ids"])
run_id2model_state_paths = {}
run_id=config['test_exp_name']
# model_path=model_state_dir+'/{}/model_state_dict_4.pt'.format(config['test_exp_name'])
model_path=config['model_path']
run_id2model_state_paths[run_id]=[]
run_id2model_state_paths[run_id].append(model_path)


def filter_duplicates(rel_list, ent_list):
# def filter_duplicates(rel_list, ent_list):
    rel_memory_set = set()
    filtered_rel_list = []
    ent_memory_set = set()
    filtered_ent_list = []

    for rel in rel_list:
        rel_memory = "{}\u2E80{}\u2E80{}\u2E80{}\u2E80{}".format(rel["subj_tok_span"][0], 
                                                                rel["subj_tok_span"][1], 
                                                                rel["predicate"], 
                                                                rel["obj_tok_span"][0], 
                                                                rel["obj_tok_span"][1])
        if rel_memory not in rel_memory_set:
            filtered_rel_list.append(rel)
            rel_memory_set.add(rel_memory)
            
    ent_memory_set = set()
    filtered_ent_list = []
    for ent in ent_list:
        ent_memory = "{}\u2E80{}\u2E80{}".format(ent["tok_span"][0], 
                                                ent["tok_span"][1], 
                                                ent["type"])   
        if ent_memory not in ent_memory_set:
            filtered_ent_list.append(ent)
            ent_memory_set.add(ent_memory)
    
                
        
    return filtered_rel_list, filtered_ent_list
    
def predict(test_data, ori_test_data):
    '''
    test_data: if split, it would be samples with subtext
    ori_test_data: the original data has not been split, used to get original text here
    '''
    indexed_test_data = data_maker.get_indexed_data(test_data, max_seq_len, data_type = "test") # fill up to max_seq_len
    test_dataloader = DataLoader(MyDataset(indexed_test_data), 
                              batch_size = batch_size, 
                              shuffle = False, 
                              num_workers = 6,
                              drop_last = False,
                              collate_fn = lambda data_batch: data_maker.generate_batch(data_batch, data_type = "test"),
                             )
    
    pred_sample_list = []
    for batch_test_data in tqdm(test_dataloader, desc = "Predicting"):
        if config["encoder"] == "BERT":
            sample_list, batch_input_ids, \
            batch_attention_mask, batch_token_type_ids, \
            tok2char_span_list, _ = batch_test_data

            batch_input_ids, \
            batch_attention_mask, \
            batch_token_type_ids = (batch_input_ids.to(device), 
                                      batch_attention_mask.to(device), 
                                      batch_token_type_ids.to(device),
                                     )

        with torch.no_grad():
            if config["encoder"] == "BERT":
                batch_pred_shaking_tag, _ = rel_extractor(batch_input_ids, 
                                                          batch_attention_mask, 
                                                          batch_token_type_ids, 
                                                         )
 

        batch_pred_shaking_tag = (batch_pred_shaking_tag > 0.).long()
        
        for ind in range(len(sample_list)):
            gold_sample = sample_list[ind]
            text = gold_sample["text"]
            text_id = gold_sample["id"]
            tok2char_span = tok2char_span_list[ind]
            pred_shaking_tag = batch_pred_shaking_tag[ind]
            tok_offset, char_offset = 0, 0
            if split_test_data:
                tok_offset, char_offset = gold_sample["tok_offset"], gold_sample["char_offset"]
            rel_list, ent_list = handshaking_tagger.decode_rel(text,
                                                     pred_shaking_tag,
                                                     tok2char_span, 
                                                     tok_offset = tok_offset, char_offset = char_offset)
            pred_sample_list.append({
                "text": text,
                "id": text_id,
                "relation_list": rel_list,
                "entity_list": ent_list,
            })
            
    # merge
    text_id2pred_res = {}
    for sample in pred_sample_list:
        text_id = sample["id"]
        if text_id not in text_id2pred_res:
            text_id2pred_res[text_id] = {
                "rel_list": sample["relation_list"],
                "ent_list": sample["entity_list"],
            }
        else:
            text_id2pred_res[text_id]["rel_list"].extend(sample["relation_list"])
            text_id2pred_res[text_id]["ent_list"].extend(sample["entity_list"])

    text_id2text = {sample["id"]:sample["text"] for sample in ori_test_data}
    merged_pred_sample_list = []
    for text_id, pred_res in text_id2pred_res.items():
        # filtered_rel_list, filtered_ent_list, filtered_event_list = filter_duplicates(pred_res["rel_list"], pred_res["ent_list"])
        filtered_rel_list, filtered_ent_list = filter_duplicates(pred_res["rel_list"], pred_res["ent_list"])
        merged_pred_sample_list.append({
            "id": text_id,
            "text": text_id2text[text_id],
            "relation_list": filtered_rel_list,
            "entity_list": filtered_ent_list,
        })
        
    return merged_pred_sample_list

def get_test_prf(pred_sample_list, gold_test_data, pattern = "whole_text"):
    text_id2gold_n_pred = {} # text id to gold and pred results
    
    for sample in gold_test_data:
        text_id = sample["id"]
        text_id2gold_n_pred[text_id] = {
            "gold_relation_list": sample["relation_list"],
            "gold_entity_list": sample["entity_list"],
            # "gold_event_list": sample["event_list"],
        }
    
    for sample in pred_sample_list:
        text_id = sample["id"]
        text_id2gold_n_pred[text_id]["pred_relation_list"] = sample["relation_list"]
        text_id2gold_n_pred[text_id]["pred_entity_list"] = sample["entity_list"]

    correct_num, pred_num, gold_num = 0, 0, 0
    ent_correct_num, ent_pred_num, ent_gold_num = 0, 0, 0
    ee_cpg_dict = {
        "trigger_iden_cpg": [0, 0, 0],
        "trigger_class_cpg": [0, 0, 0],
        "arg_iden_cpg": [0, 0, 0],
        "arg_class_cpg": [0, 0, 0],
        }
    ere_cpg_dict = {
            "rel_cpg": [0, 0, 0],
            "ent_cpg": [0, 0, 0],
            }
    for gold_n_pred in text_id2gold_n_pred.values():
        gold_rel_list = gold_n_pred["gold_relation_list"]
        pred_rel_list = gold_n_pred["pred_relation_list"] if "pred_relation_list" in gold_n_pred else []
        gold_ent_list = gold_n_pred["gold_entity_list"]
        pred_ent_list = gold_n_pred["pred_entity_list"] if "pred_entity_list" in gold_n_pred else []

        if pattern == "event_extraction":
            pred_event_list = handshaking_tagger.trans2ee(pred_rel_list, pred_ent_list) # transform to event list
            gold_event_list = gold_n_pred["gold_event_list"] # *
            metrics.cal_event_cpg(pred_event_list, gold_event_list, ee_cpg_dict)
        else:
            metrics.cal_rel_cpg(pred_rel_list, pred_ent_list, gold_rel_list, gold_ent_list, ere_cpg_dict, pattern)
       
    if pattern == "event_extraction":
        trigger_iden_prf = metrics.get_prf_scores(ee_cpg_dict["trigger_iden_cpg"][0], 
                                                  ee_cpg_dict["trigger_iden_cpg"][1], 
                                                  ee_cpg_dict["trigger_iden_cpg"][2])
        trigger_class_prf = metrics.get_prf_scores(ee_cpg_dict["trigger_class_cpg"][0], 
                                                  ee_cpg_dict["trigger_class_cpg"][1], 
                                                  ee_cpg_dict["trigger_class_cpg"][2])
        arg_iden_prf = metrics.get_prf_scores(ee_cpg_dict["arg_iden_cpg"][0], ee_cpg_dict["arg_iden_cpg"][1], ee_cpg_dict["arg_iden_cpg"][2])
        arg_class_prf = metrics.get_prf_scores(ee_cpg_dict["arg_class_cpg"][0], ee_cpg_dict["arg_class_cpg"][1], ee_cpg_dict["arg_class_cpg"][2])
        prf_dict = {
            "trigger_iden_prf": trigger_iden_prf,
            "trigger_class_prf": trigger_class_prf,
            "arg_iden_prf": arg_iden_prf,
            "arg_class_prf": arg_class_prf,
        }
        return prf_dict
    else:
        rel_prf = metrics.get_prf_scores(ere_cpg_dict["rel_cpg"][0], ere_cpg_dict["rel_cpg"][1], ere_cpg_dict["rel_cpg"][2])
        ent_prf = metrics.get_prf_scores(ere_cpg_dict["ent_cpg"][0], ere_cpg_dict["ent_cpg"][1], ere_cpg_dict["ent_cpg"][2])
        prf_dict = {
            "rel_prf": rel_prf,
            "ent_prf": ent_prf,
        }
        return prf_dict

# predict
res_dict = {}
predict_statistics = {}
for file_name, short_data in test_data_dict.items():
    ori_test_data = ori_test_data_dict[file_name]
    for run_id, model_path_list in run_id2model_state_paths.items():
        # save_dir4run = os.path.join(save_res_dir, run_id)
        save_dir4run = save_res_dir
        if config["save_res"] and not os.path.exists(save_dir4run):
            os.makedirs(save_dir4run)
            
        for model_state_path in model_path_list:

            save_path = os.path.join(save_dir4run, "result.jsonlines")
            
            if os.path.exists(save_path):
                pred_sample_list = [json.loads(line) for line in open(save_path, "r", encoding = "utf-8")]
                print("{} already exists, load it directly!".format(save_path))
            else:
                # load model state
                rel_extractor.load_state_dict(torch.load(model_state_path))
                rel_extractor.eval()
                print("run_id: {}, model state {} loaded".format(run_id, model_state_path.split("/")[-1]))

                # predict
                pred_sample_list = predict(short_data, ori_test_data)
            
            res_dict[save_path] = pred_sample_list
            predict_statistics[save_path] = len([s for s in pred_sample_list if len(s["relation_list"]) > 0])
# pprint(predict_statistics)

# check
for path, res in res_dict.items():
    for sample in tqdm(res, desc = "check char span"):
        text = sample["text"]
        for rel in sample["relation_list"]:
            assert rel["subject"] == text[rel["subj_char_span"][0]:rel["subj_char_span"][1]]
            assert rel["object"] == text[rel["obj_char_span"][0]:rel["obj_char_span"][1]]

# save 
if config["save_res"]:
    for path, res in res_dict.items():
        with jsonlines.open(path, "w") as file_out:
            for sample in tqdm(res, desc = "Output"):
                # if len(sample["relation_list"]) == 0:
                #     continue
                # json_line = jsonlines.open(sample, ensure_ascii = False)     
                # file_out.write("{}\n".format(json_line))
                file_out.write(sample)

# score
if config["score"]:
    filepath2scores = {}
    for file_path, pred_samples in res_dict.items():
        # file_name = re.search("(.*?)_res_\d+\.json", file_path.split("/")[-1]).group(1)
        gold_test_data = ori_test_data_dict['test']
        prf_dict = get_test_prf(pred_samples, gold_test_data, pattern = config["hyper_parameters"]["match_pattern"])
        filepath2scores[file_path] = prf_dict
    print("---------------- Results -----------------------")
    pprint(filepath2scores)



